
### adder

Train a GPT model to add n-digit numbers
